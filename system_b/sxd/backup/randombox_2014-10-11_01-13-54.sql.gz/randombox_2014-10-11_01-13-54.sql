#SXD20|20011|50538|50328|2014.10.11 01:13:54|randombox|0|16|85|
#TA t_bad_login`0`28|t_email_settings`3`120|t_gallery_list`3`16384|t_gallery_rights`3`16384|t_groups`3`16384|t_images`4`16384|t_pass_restore`0`16384|t_rights`45`16384|t_rights_category`10`16384|t_rights_list`0`16384|t_site_settings`7`208|t_users`1`368|t_users_in_groups`0`16384|t_vgallery_rights`2`16384|t_video_gallery_list`2`16384|t_videos`2`16384
#EOH

#	TC`t_bad_login`cp1251_general_ci	;
CREATE TABLE `t_bad_login` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `last_timestamp` int(10) NOT NULL,
  `count` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=cp1251	;
#	TC`t_email_settings`cp1251_general_ci	;
CREATE TABLE `t_email_settings` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `value` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=cp1251	;
#	TD`t_email_settings`cp1251_general_ci	;
INSERT INTO `t_email_settings` VALUES 
(1,'email_name','Random-box'),
(2,'confirm_email','noreply@random-box.com'),
(3,'fp_email','noreply@random-box.com')	;
#	TC`t_gallery_list`utf8_general_ci	;
CREATE TABLE `t_gallery_list` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `active` varchar(1) NOT NULL DEFAULT 'Y',
  `type` varchar(2) NOT NULL DEFAULT 'c',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`t_gallery_list`utf8_general_ci	;
INSERT INTO `t_gallery_list` VALUES 
(1,'default','Default','Y','s'),
(12,'sdad','adad','Y','c'),
(13,'sfsfsdff','dsfsfd','Y','c')	;
#	TC`t_gallery_rights`utf8_general_ci	;
CREATE TABLE `t_gallery_rights` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `group_id` int(5) NOT NULL,
  `gallery_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`t_gallery_rights`utf8_general_ci	;
INSERT INTO `t_gallery_rights` VALUES 
(1,1,1),
(2,1,12),
(3,1,13)	;
#	TC`t_groups`utf8_general_ci	;
CREATE TABLE `t_groups` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `name_en` varchar(50) NOT NULL,
  `description_en` tinytext NOT NULL,
  `name_ru` varchar(50) NOT NULL,
  `description_ru` tinytext NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` varchar(1) NOT NULL DEFAULT 'Y',
  `type` varchar(2) NOT NULL DEFAULT 'c',
  `rang` int(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`t_groups`utf8_general_ci	;
INSERT INTO `t_groups` VALUES 
(1,'admins','Admins','','Администраторы','','2014-10-11 00:49:35','Y','s',900),
(2,'registered','Registered','','Зарегестированные пользователи','','2014-10-11 00:50:52','Y','s',100),
(3,'all_users','All users','','Все пользователи','','2014-10-11 00:51:33','Y','s',1)	;
#	TC`t_images`utf8_general_ci	;
CREATE TABLE `t_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(4) NOT NULL,
  `size` int(10) NOT NULL,
  `height` int(6) NOT NULL,
  `width` int(6) NOT NULL,
  `md5` varchar(32) NOT NULL,
  `animated` varchar(1) NOT NULL DEFAULT 'N',
  `activated` varchar(1) NOT NULL DEFAULT 'N',
  `gallery_id` int(5) NOT NULL,
  `active` varchar(1) NOT NULL DEFAULT 'M',
  `deleted` varchar(1) NOT NULL DEFAULT 'N',
  `moderator_id` int(11) NOT NULL,
  `date_insert` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`,`md5`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`t_images`utf8_general_ci	;
INSERT INTO `t_images` VALUES 
(1,'/system_b/upload/images/0f/ce/04/0fce04d0194781e65e6e1888620a2e2c.jpg','14121771305600.jpg','jpg',53099,1000,1000,'0fce04d0194781e65e6e1888620a2e2c','N','Y',12,'M','Y',0,1412199962),
(2,'/system_b/upload/images/9c/01/86/9c018699520c3e2df3ce6cd67bc50138.jpg','14121654777470.jpg','jpg',119968,807,807,'9c018699520c3e2df3ce6cd67bc50138','N','Y',12,'M','N',0,1412199963),
(3,'/system_b/upload/images/7c/8b/33/7c8b33fbb6ceaebb5c7398fcfed8ab9f.jpg','vq3iei6rXYQ.jpg','jpg',65604,604,453,'7c8b33fbb6ceaebb5c7398fcfed8ab9f','N','Y',12,'Y','N',0,1412200825),
(4,'/system_b/upload/images/27/63/33/276333d889a9fa9a932d01c8c41333a6.jpg','1-130126091103.jpg','jpg',380923,800,1280,'276333d889a9fa9a932d01c8c41333a6','N','Y',12,'Y','N',0,1412280181)	;
#	TC`t_pass_restore`utf8_general_ci	;
CREATE TABLE `t_pass_restore` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `hash_code` varchar(32) NOT NULL,
  `date_create` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`t_rights`utf8_general_ci	;
CREATE TABLE `t_rights` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `name_en` varchar(50) NOT NULL,
  `description_en` tinytext NOT NULL,
  `name_ru` varchar(50) NOT NULL,
  `description_ru` tinytext NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` varchar(2) NOT NULL DEFAULT 'c',
  `category` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8	;
#	TD`t_rights`utf8_general_ci	;
INSERT INTO `t_rights` VALUES 
(1,'new_right_add','New right add','','Добавление нового права','','2014-10-04 19:57:25','s',2),
(2,'right_edit','Right edit','','Редактирование права','','2014-10-04 20:36:19','s',2),
(3,'read_rights_list','Read rights list','','Просмотр списка прав','','2014-10-05 15:57:13','s',2),
(4,'new_group_add','New group add','','Добавление новой группы','','2014-10-05 16:04:22','s',2),
(5,'group_edit','Group edit','','Редактирование группы','','2014-10-05 16:09:58','s',2),
(6,'read_groups_list','Read groups list','','Просмотр списка групп','','2014-10-05 16:18:37','s',2),
(7,'right_delete','Right delete','','Удаление права','','2014-10-05 16:26:12','s',2),
(8,'group_delete','Group delete','','Удаление группы','','2014-10-05 16:26:40','s',2),
(9,'add_user','Add user','','Добавление пользователя','','2014-10-06 20:14:34','s',1),
(10,'read_users_list','Read users list','','Просмотр списка пользователей','','2014-10-06 20:23:02','s',1),
(11,'user_edit','User edit','','Редактирование пользователя','','2014-10-06 20:44:54','s',1),
(12,'user_delete','User delete','','Удаление пользователя','','2014-10-06 20:53:34','s',1),
(13,'read_galleries_list','Read galleries list of images','','Просмотр списка галерей изображений','','2014-10-06 23:25:23','s',8),
(14,'add_gallery','Add gallery','','Добавление галереи','','2014-10-07 22:58:07','s',8),
(15,'gallery_delete','Gallery delete','','Удаление галереи','','2014-10-07 23:03:21','s',8),
(16,'edit_gallery','Edit gallery','','Редактирование галереи','','2014-10-07 23:12:36','s',8),
(17,'clear_gallery','Clear gallery','','Очистка галереи','','2014-10-07 23:51:05','s',8),
(18,'read_gallery','Read gallery','','Просмотр галереи','','2014-10-08 00:23:23','s',8),
(19,'activate_image','Activate image','','Активировать изображение','','2014-10-08 00:27:46','s',8),
(20,'deactivate_image','Deactivate image','','Деактивировать изображения','','2014-10-08 00:28:23','s',8),
(21,'delete_wink_image','Delete image wink','','Удаление изображения wink','','2014-10-08 00:29:26','s',8),
(22,'restore_image_wink','Restore image wink','','Восстановить изображения wink','','2014-10-08 00:30:09','s',8),
(23,'delete_image','Delete image','','Удаление изображения','','2014-10-08 00:30:46','s',8),
(24,'read_deleted_gallery','Read deleted gallery','','Просмотр галереи удаленых изображений','','2014-10-08 00:43:41','s',8),
(25,'read_video_galleries_list','Read video galleries list','','Просмотр списка видео галерей','','2014-10-08 20:37:40','s',9),
(26,'add_video_gallery','Add video gallery','','Добавление видео галереи','','2014-10-08 20:39:10','s',9),
(27,'video_gallery_delete','Video gallery delete','','Удаление видео галереи','','2014-10-08 20:39:46','s',9),
(28,'edit_video_gallery','Edit video gallery','','Редактирование видео галереи','','2014-10-08 20:40:56','s',9),
(29,'read_video_gallery','Read video gallery','','Просмотр видео галереи','','2014-10-08 20:42:31','s',9),
(30,'activate_video','Activate video','','Активировать видео','','2014-10-08 20:43:03','s',9),
(31,'deactivate_video','Deactivate video','','Деактивировать видео','','2014-10-08 20:43:20','s',9),
(32,'delete_wink_video','Delete video wink','','Удаление видео wink','','2014-10-08 20:44:46','s',9),
(33,'restore_video_wink','Restore video wink','','Восстановить видео wink','','2014-10-08 20:45:22','s',9),
(34,'delete_video','Delete video','','Удаление видео','','2014-10-08 20:46:38','s',9),
(35,'read_deleted_video_gallery','Read deleted video gallery','','Просмотр галереи удаленых видео','','2014-10-08 20:48:19','s',9),
(36,'clear_video_gallery','Clear video gallery','','Очистка видео галереи','','2014-10-08 21:25:56','s',9),
(37,'image_add_to_gallery','Image add to gallery page','','Добавление изображения в галерею','','2014-10-08 21:45:47','s',8),
(38,'video_add_to_gallery','Video add to gallery page','','Добавление видео в галерею','','2014-10-08 21:47:35','s',9),
(39,'main_settings','Main settings','','Доступ к основным настройкам','','2014-10-09 20:13:59','s',3),
(40,'email_settings','Email settings','','Доступ к настройкам почты','','2014-10-09 20:20:19','s',3),
(41,'global_menu_user','Global menu user','','Отображать вкладку  Пользователи','','2014-10-09 21:00:53','s',1),
(42,'global_menu_images','Global menu images','','Отображать вкладку  Изображения','','2014-10-09 21:02:59','s',8),
(43,'global_menu_videos','Global menu videos','','Отображать вкладку  Видео','','2014-10-09 21:03:27','s',9),
(44,'global_menu_settings','Global menu settings','','Отображать вкладку  Настройки','','2014-10-09 21:04:00','s',3),
(45,'admin_page_access','Access to admin side','','Доступ к админке','','2014-10-10 20:28:21','s',10)	;
#	TC`t_rights_category`utf8_general_ci	;
CREATE TABLE `t_rights_category` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `name_en` varchar(50) NOT NULL,
  `name_ru` varchar(50) NOT NULL,
  `type` varchar(2) NOT NULL DEFAULT 'c',
  `order` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`t_rights_category`utf8_general_ci	;
INSERT INTO `t_rights_category` VALUES 
(1,'users','Users','Пользователи','s',111),
(2,'groups','Groups','Группы','s',111),
(3,'settings','Settings','Настройки','s',111),
(4,'datebase','Date base','База данных','s',111),
(5,'market','Market','Маркет','s',111),
(6,'Adverts','Adverts','Объявления','s',111),
(7,'others','Others','Разное','s',999),
(8,'images','Images','Изображения','s',112),
(9,'videos','Videos','Видео','s',112),
(10,'main','Main','Главные','s',11)	;
#	TC`t_rights_list`utf8_general_ci	;
CREATE TABLE `t_rights_list` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `group_id` int(5) NOT NULL,
  `right_id` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `group_id_2` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`t_site_settings`cp1251_general_ci	;
CREATE TABLE `t_site_settings` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `value` tinytext NOT NULL,
  `description` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=cp1251	;
#	TD`t_site_settings`cp1251_general_ci	;
INSERT INTO `t_site_settings` VALUES 
(1,'login_max_len','21',''),
(2,'password_max_len','21',''),
(3,'login_min_len','4',''),
(4,'password_min_len','4',''),
(5,'use_email','1',''),
(6,'activation_timer','6',''),
(7,'use_captcha','1','')	;
#	TC`t_users`cp1251_general_ci	;
CREATE TABLE `t_users` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `login` varchar(30) NOT NULL,
  `pass` varchar(70) NOT NULL,
  `email` varchar(255) NOT NULL,
  `active_confirmation` int(1) NOT NULL,
  `date_create` int(11) NOT NULL,
  `date_update` int(11) NOT NULL,
  `date_update_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` varchar(1) NOT NULL DEFAULT 'Y',
  `rang` int(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=cp1251	;
#	TD`t_users`cp1251_general_ci	;
INSERT INTO `t_users` VALUES 
(1,'admin','e273e1412180e2dcea38b8083804f7e2aa9647136be53f9191781aa6e0532d937TEnjb','',1,1412525466,1412974061,'2014-10-11 00:47:41','Y',1)	;
#	TC`t_users_in_groups`utf8_general_ci	;
CREATE TABLE `t_users_in_groups` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `group_id` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TC`t_vgallery_rights`utf8_general_ci	;
CREATE TABLE `t_vgallery_rights` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `group_id` int(5) NOT NULL,
  `gallery_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`t_vgallery_rights`utf8_general_ci	;
INSERT INTO `t_vgallery_rights` VALUES 
(1,1,1),
(2,1,6)	;
#	TC`t_video_gallery_list`utf8_general_ci	;
CREATE TABLE `t_video_gallery_list` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `active` varchar(1) NOT NULL DEFAULT 'Y',
  `type` varchar(1) NOT NULL DEFAULT 'c',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`t_video_gallery_list`utf8_general_ci	;
INSERT INTO `t_video_gallery_list` VALUES 
(1,'default','Default','Y','s'),
(6,'gfgffgf','рлоролллллророр орор рлллллллллллллрорл рлорр лор','Y','c')	;
#	TC`t_videos`utf8_general_ci	;
CREATE TABLE `t_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) NOT NULL,
  `url_video_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `source` varchar(30) NOT NULL,
  `gallery_id` int(5) NOT NULL,
  `active` varchar(1) NOT NULL DEFAULT 'M',
  `deleted` varchar(1) NOT NULL DEFAULT 'N',
  `moderator_id` int(11) NOT NULL,
  `date_insert` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`t_videos`utf8_general_ci	;
INSERT INTO `t_videos` VALUES 
(1,'http://www.youtube.com/watch?v=FhT14ZSJuw4','FhT14ZSJuw4','покер','youtube',1,'N','N',1,1412270451),
(3,'http://www.youtube.com/watch?v=FhT14ZSJuw4','FhT14ZSJuw4','Фил Хельмут','youtube',4,'Y','N',1,1412353093)	;
